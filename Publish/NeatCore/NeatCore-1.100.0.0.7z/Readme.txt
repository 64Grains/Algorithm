NeatCore
~~~~~~~~~~~~~~~~~~
Version: 1.100.0.0

Dependend:
  gtest

Update record:
_________
1.100.0.0  2020-01-21  12:00  dquan2007@163.com
  Initially built NeatCore static library for defining basic data types and public function interfaces.